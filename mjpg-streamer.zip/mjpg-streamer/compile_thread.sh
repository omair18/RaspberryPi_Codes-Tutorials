rm a.out
gcc threads.c -lwiringPi -lpthread
sudo ./a.out
