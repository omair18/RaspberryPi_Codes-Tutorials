rm BOT
gcc finalcode.c -o BOT -lwiringPi -lpthread
sudo ./BOT
