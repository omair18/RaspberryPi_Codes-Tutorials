rm a.out
gcc stream_servo_pwm_robot_motor_code.c -lwiringPi -lpthread
sudo ./a.out
