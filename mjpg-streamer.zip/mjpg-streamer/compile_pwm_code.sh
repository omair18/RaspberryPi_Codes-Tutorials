rm a.out
gcc servo_pwm_robot_motor_code.c -lwiringPi -lpthread
./a.out
