#include <pthread.h>
#include <wiringPi.h>

#include "gpiooutputcycle.h"

#define OFF 0
#define ON 1
#define DELAY_TIME 10

GPIOOutputCycle::GPIOOutputCycle(GPIOHandler *handler)
{
  this->gpioHandler = handler;
}

GPIOOutputCycle::~GPIOOutputCycle()
{
  stop();
}

void GPIOOutputCycle::addPin(int pinNumber, int onTime, int offTime)
{
  piLock(3);

  stop();

  for (std::vector<CyclePin>::iterator it = cyclePins.begin() ; it != cyclePins.end(); ++it)
  {
    if((*it).pinNumber == pinNumber)
    {
      cyclePins.erase(it);
      break;
    }
  }

  CyclePin pin;
  pin.pinNumber = pinNumber;
  pin.pinState = OFF;
  pin.offTime = offTime;
  pin.onTime=  onTime;
  pin.currentTime = 0;
  cyclePins.push_back(pin);


  start();
  piUnlock(3);

}

void GPIOOutputCycle::removePin(int pinNumber)
{
  piLock(3);
  stop();
  digitalWrite(pinNumber,LOW);
  for (std::vector<CyclePin>::iterator it = cyclePins.begin() ; it != cyclePins.end(); ++it)
  {
    if((*it).pinNumber == pinNumber)
    {
      cyclePins.erase(it);
      break;

    }
  }
  if(cyclePins.size() > 0)
  {
    start();
  }
  piUnlock(3);
}

void GPIOOutputCycle::removeAllPins()
{
  piLock(3);
  stop();
  cyclePins.clear();
  piUnlock(3);
}


void GPIOOutputCycle::run(void)
{
  unsigned int ms = millis();
  while (!stopFlag)
  {


    delay(DELAY_TIME - (millis() - ms));
    ms = millis();
    piLock(3);
    for (std::vector<CyclePin>::iterator it = cyclePins.begin() ; it != cyclePins.end(); ++it)
    {
      if(stopFlag)
      {
        piUnlock(3);
        return;
      }

      if((*it).currentTime <= 0)
      {
        // change cycle.
        if((*it).pinState == OFF)
        {
          (*it).pinState = ON;
          digitalWrite((*it).pinNumber,HIGH);
          (*it).currentTime = (*it).onTime;
        }else
        {
          (*it).pinState = OFF;
          digitalWrite((*it).pinNumber,LOW);
          (*it).currentTime = (*it).offTime;
        }
      }else
      {
        (*it).currentTime = (*it).currentTime - (DELAY_TIME - (millis() - ms));
      }
    }
    piUnlock(3);

  }

}



