#include "ds18b20handler.h"

#define BASE_PATH "/sys/bus/w1/devices/"
#define DEVICE_START "28-"
#define READ_FROM "w1_slave"
#define PI_TEMP_DEVICE "/sys/class/thermal/thermal_zone0/temp"

#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <iterator>
#include <fstream>
//#include <alogrithm>

DS18B20Handler::DS18B20Handler(GPIOHandler *gioHandler):Handler("DS18B20"),gpioHandler(gioHandler)
{
   mStop = false;
  mSampleTimeMS = 5000;
}

DS18B20Handler::~DS18B20Handler()
{
  stop();
}

bool DS18B20Handler::handler(const std::vector<std::string> &values)
{
 if(values[0] == id())
  {
    std::string command = values[1];

    if(command == std::string("INIT"))
    {
      init();
      return true;
    }else if(command == std::string("SAMPLE"))
    {
      /**< DS18B20 SAMPLE [sample time ms] */
      mSampleTimeMS = toInt(values[2]);
    }else if(command == std::string("START"))
    {
      /**< DS18B20 START (start reading temperature values)*/
      start();
    }else if(command == std::string("STOP"))
    {
      /**< DS18B20 STOP (stop reading temperature values)*/
      stop();
    }
  }
  return false;

}

// 3c 01 4b 46 7f ff 04 10 40 : crc=40 YES
// 3c 01 4b 46 7f ff 04 10 40 t=19750

void DS18B20Handler::run()
{
  //writeString("run");
  while(!mStop)
  {
    struct dirent *dp;
    DIR *dir = opendir(BASE_PATH);
    while((dp = readdir(dir)) != NULL)
    {
      std::string found(dp->d_name);


      if(found.find_first_of(DEVICE_START) == 0)
      {
        std::string readfile = BASE_PATH + found + "/" + READ_FROM;
       // writeString("readfile = " + readfile );

        std::ifstream ifs(readfile.c_str());
        //ifs.open(readfile);//,std::ifstream::in);
        if(ifs.good())
        {

          std::vector<std::string> lines;
          std::string line;
          std::getline(ifs,line);
          while(!ifs.eof())
          {
            lines.push_back(line);
            std::getline(ifs,line);
          }

          //char test[20];
          //sprintf(test,"good lines %d",(int)lines.size());
          //writeString(test);
          if(lines.size() == 2)
          {

            std::vector<std::string> line1;
            std::vector<std::string> line2;
            //writeString(line1[0]);
            //writeString(line2[1]);
            split(line1,lines[0]," ",no_empties);
            split(line2,lines[1]," ",no_empties);
            std::string checksumok = line1[line1.size() - 1];
            std::string temp = line2[line2.size() - 1];
            int pos = temp.find("=");
            temp.erase(0,pos+1);

            std::stringstream result;
            result << id() << " VALUE " << found << " " <<checksumok << " " << temp;
            writeString(result.str());
          }
        }
        ifs.close();
      }

    }
    closedir(dir);

    // rpi temp
    std::ifstream ifs(PI_TEMP_DEVICE);
    if(ifs.good())
    {
      std::string line;
      std::getline(ifs,line);

      std::string checksumok = line.compare(std::string("85000")) ? "YES" : "NO";
      std::stringstream result;
      result << id() << " VALUE " << "RaspberryPi" << " " <<checksumok << " " << line;
      writeString(result.str());
    }
    ifs.close();

    if(!mStop)
    {
      delay(mSampleTimeMS);
    }
  }

}

void DS18B20Handler::init()
{
  piLock (0);
  system ("sudo /sbin/modprobe w1-gpio");
  system ("sudo /sbin/modprobe w1-therm");
  piUnlock (0);
}

static void* startHandler(void *ptr)
{
 DS18B20Handler *itrpt = static_cast<DS18B20Handler*>(ptr);
 itrpt->run();
}

void DS18B20Handler::start()
{
  mStop = false;
  pthread_create(&ptt,NULL,startHandler,this);

}

void DS18B20Handler::stop()
{
  mStop = true;
}
