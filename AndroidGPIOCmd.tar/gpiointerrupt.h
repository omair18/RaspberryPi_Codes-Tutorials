#ifndef GPIOINTERRUPT_H
#define GPIOINTERRUPT_H

#include "gpiohandler.h"
#include "gpiothreadbase.h"
#include <vector>

class InterruptPin
{
public:
  int pinNumber;
  int pinState;

};

class GPIOInterrupt : public GPIOThreadBase
{
  public:
    GPIOInterrupt(GPIOHandler *handler);
    virtual ~GPIOInterrupt();


    virtual void addPin(int pinNumber, int n1, int n2);
    virtual void removePin(int pinNumber);
    virtual void removeAllPins();

    virtual void run(void);


  protected:
  private:
    std::vector<InterruptPin> interruptPins;
        GPIOHandler *gpioHandler;


};

#endif // GPIOINTERRUPT_H
