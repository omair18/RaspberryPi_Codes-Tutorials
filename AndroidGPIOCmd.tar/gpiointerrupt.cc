#include <pthread.h>
#include <wiringPi.h>

#include "gpiointerrupt.h"



GPIOInterrupt::GPIOInterrupt( GPIOHandler *handler): GPIOThreadBase()
{
  gpioHandler = handler;

}

GPIOInterrupt::~GPIOInterrupt()
{
  stop();
}

void GPIOInterrupt::addPin(int pinNumber, int, int)
{
  piLock (2);

  stop();

  for (std::vector<InterruptPin>::iterator it = interruptPins.begin() ; it != interruptPins.end(); ++it)
  {
    if((*it).pinNumber == pinNumber)
    {
      interruptPins.erase(it);
      break;
    }
  }

  InterruptPin pin;
  pin.pinNumber = pinNumber;
  pin.pinState = digitalRead(pinNumber);
  interruptPins.push_back(pin);


  start();
  piUnlock(2);

}

void GPIOInterrupt::removePin(int pinNumber)
{
  piLock (2);
  stop();
  for (std::vector<InterruptPin>::iterator it = interruptPins.begin() ; it != interruptPins.end(); ++it)
  {
    if((*it).pinNumber == pinNumber)
    {
      interruptPins.erase(it);
      break;

    }
  }
  if(interruptPins.size() > 0)
  {
    start();
  }
  piUnlock (2);
}

void GPIOInterrupt::removeAllPins()
{
  piLock (2);
  stop();
  interruptPins.clear();
  piUnlock (2);
}


void GPIOInterrupt::run(void)
{
  while (!stopFlag)
  {


    delay(20);
    piLock (2);

    for (std::vector<InterruptPin>::iterator it = interruptPins.begin() ; it != interruptPins.end(); ++it)
    {
      if(stopFlag)
      {
        piUnlock(2);
        return;

      }
      int currentState = digitalRead((*it).pinNumber);
      if(currentState != (*it).pinState)
      {
        gpioHandler->getPin((*it).pinNumber);
        (*it).pinState = currentState;
      }
    }
    piUnlock(2);
  }
}


