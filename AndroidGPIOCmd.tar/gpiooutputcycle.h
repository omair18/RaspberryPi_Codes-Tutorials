#ifndef GPIOOUTPUTCYCLE_H
#define GPIOOUTPUTCYCLE_H

#include "gpiohandler.h"
#include "gpiothreadbase.h"
#include <vector>


class CyclePin
{
public:
  int pinNumber;
  int pinState;
  int onTime;
  int offTime;
  int currentTime;
};

class GPIOOutputCycle : public GPIOThreadBase
{
  public:
    GPIOOutputCycle(GPIOHandler *handler);
    virtual ~GPIOOutputCycle();

    virtual void addPin(int pinNumber, int onTime, int offTime);
    virtual void removePin(int pinNumber);

    virtual void removeAllPins();
    virtual void run(void);


  protected:
  private:
    std::vector<CyclePin> cyclePins;
    GPIOHandler *gpioHandler;
};

#endif // GPIOOUTPUTCYCLE_H
