#ifndef DS18B20HANDLER_H
#define DS18B20HANDLER_H

#include <vector>
#include <string>
#include <map>
#include "handler.h"
#include "gpiohandler.h"

class DS18B20Handler: public Handler
{
  public:
    pthread_t ptt;
    DS18B20Handler(GPIOHandler *gioHandler);
    virtual ~DS18B20Handler();
    virtual bool handler(const std::vector<std::string> &values);
    void run();
  protected:
  private:
    GPIOHandler *gpioHandler;
    int mSampleTimeMS;
    bool mStop;
    void init();

    void start();
    void stop();
};


#endif // DS18B20HANDLER_H
