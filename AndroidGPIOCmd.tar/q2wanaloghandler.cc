#include "q2wanaloghandler.h"
#include <wiringPi.h>
#include <pcf8591.h>
#include <stdlib.h>
#include <iostream>
#include <unistd.h>
#include <string>
#include <sstream>

#define Q2W_ABASE 120
#define NUM_IN_PINS 4
#define OUTPUT_PIN Q2W_ABASE + NUM_IN_PINS + 1

Q2WAnalogHandler::Q2WAnalogHandler():Handler("Q2WA")
{
  mStop = false;
  mSampleTimeMS = 1000;
}

Q2WAnalogHandler::~Q2WAnalogHandler()
{
  stop();
}

/** \brief handle incoming message
 *
 * \param values - string of parameters
 * \return true if handled, false if not
 *
 */
bool Q2WAnalogHandler::handler(const std::vector<std::string> &values)
{
  if(values[0] == id())
  {
    std::string command = values[1];

    if(command == std::string("INIT"))
    {
      /**< Q2WA INIT (I2C Address)[0x48] */
      init(values[2]);
      return true;
    }else if(command == std::string("READ"))
    {
      /**< Q2WA READ [pin] */
      int pin = toInt(values[2]);
      int value = analogRead  (pin) ;
      std::stringstream result2;
      result2 << id() << " VALUE " << pin << " " << value;
      writeString(result2.str());
      return true;
    }else if(command == std::string("WRITE"))
    {
      /**< Q2A WRITE [value] */
      int pin = Q2W_ABASE;
      int value = toInt(values[2]);
      analogWrite(pin, value);
      std::stringstream result2;
      result2 << id() << " VALUE " << OUTPUT_PIN << " " << value;
      writeString(result2.str());
      return true;
    }else if(command == std::string("SAMPLE"))
    {
      /**< Q2WA SAMPLE [sample time ms] */
      mSampleTimeMS = toInt(values[2]);
    }else if(command == std::string("START"))
    {
      /**< Q2WA START (start reading analog values)*/
      start();
    }else if(command == std::string("STOP"))
    {
      /**< Q2WA STOP (stop reading analog values)*/
      stop();
    }
  }
  return false;
}

void Q2WAnalogHandler::init(const std::string &i2caddress)
{
  pcf8591Setup (Q2W_ABASE,  toInt(i2caddress)) ;
}

static void* startHandler(void *ptr)
{
 Q2WAnalogHandler *itrpt = static_cast<Q2WAnalogHandler*>(ptr);
 itrpt->run();
}

void Q2WAnalogHandler::start()
{
  mStop = false;
  pthread_create(&ptt,NULL,startHandler,this);
}

void Q2WAnalogHandler::stop()
{
  mStop = true;
}

void Q2WAnalogHandler::run()
{
  while(!mStop)
  {
    std::stringstream result2;
    for(int pin = 0; pin < NUM_IN_PINS; pin++)
    {
      int value = analogRead  (Q2W_ABASE + pin) ;
      if(pin > 0)
        result2 << std::endl;
      result2 << id() << " VALUE " << Q2W_ABASE + pin << " " << value;
    }
    writeString(result2.str());
    if(!mStop)
    {
      delay(mSampleTimeMS);
    }
  }
}


