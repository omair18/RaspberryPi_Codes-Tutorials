#include <wiringPi.h>
#include <iostream>
#include <stdlib.h>
#include "handler.h"

Handler::Handler(const std::string& identifier):m_identifier(identifier)
{
  //ctor
}

Handler::~Handler()
{
  //dtor
}

std::string Handler::id()
{
  return m_identifier;
}

void Handler::writeString(const std::string &in)
{
  piLock (0);
  std::cout << in << std::endl;
  piUnlock(0);
}

int Handler::toInt(const std::string &in)
{
  char *endptr;
  return strtol(in.c_str(),&endptr,0);
}


std::vector<std::string>& split(
  std::vector<std::string>&result,
  const std::string& s,
  const std::string& delimiters,
  empties_t empties )
{
  result.clear();
  size_t next = -1;
  do
  {
    if (empties == no_empties)
    {
      next = s.find_first_not_of( delimiters, next + 1 );
      if (next == std::vector<std::string>::value_type::npos)
      {
        break;
      }
      next -= 1;
    }
    size_t current = next + 1;
    next = s.find_first_of( delimiters, current );
    result.push_back( s.substr( current, next - current ) );
  }
  while (next != std::vector<std::string>::value_type::npos);
  return result;
}
