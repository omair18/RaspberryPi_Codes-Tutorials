#include "lcdhandler.h"

#include <wiringPi.h>
#include <mcp23017.h>
#include <lcd.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <string>
#include <sstream>

#ifndef	TRUE
#  define	TRUE	(1==1)
#  define	FALSE	(1==2)
#endif


// Defines for the Adafruit Pi LCD interface board

#define	AF_BASE		100
#define	AF_RED		(AF_BASE + 6)
#define	AF_GREEN	(AF_BASE + 7)
#define	AF_BLUE		(AF_BASE + 8)

#define	AF_E		(AF_BASE + 13)
#define	AF_RW		(AF_BASE + 14)
#define	AF_RS		(AF_BASE + 15)

#define	AF_DB4		(AF_BASE + 12)
#define	AF_DB5		(AF_BASE + 11)
#define	AF_DB6		(AF_BASE + 10)
#define	AF_DB7		(AF_BASE +  9)

#define	AF_SELECT	(AF_BASE +  0)
#define	AF_RIGHT	(AF_BASE +  1)
#define	AF_DOWN		(AF_BASE +  2)
#define	AF_UP		  (AF_BASE +  3)
#define	AF_LEFT		(AF_BASE +  4)

static std::string buttonNames[] = {"SELECT","RIGHT","DOWN","UP","LEFT"};

LCDHandler::LCDHandler(): Handler("LCD")
{
  lcdHandle = -1;
  stopFlag = false;
}

LCDHandler::~LCDHandler()
{
  close(lcdHandle);
}

bool LCDHandler::handler(const std::vector<std::string> &values)
{
  if(values[0] == id())
  {
    std::string command = values[1];

    if(command == std::string("INIT"))
    {
      if(values[2] == std::string("ADAFRUIT"))
      {
        initAdafruit(values[3]);
        return true;
      }

    }else if(command == std::string("BACKLIGHT"))
    {
      int r = toInt(values[2]);
      int g = toInt(values[3]);
      int b = toInt(values[4]);

      setBacklightColour(r,g,b);
      return true;
    }else if(command == std::string("LINE1"))
    {
      setText(0,0,values);
      return true;
    }else if(command == std::string("LINE2"))
    {
      setText(0,1,values);
      return true;
    }else if(command == std::string("CLEAR"))
    {
      lcdClear(lcdHandle);
      return true;
    }else if(command == std::string("HOME"))
    {
      lcdHome(lcdHandle);
      return true;
    }else if(command == std::string("ON"))
    {
      lcdDisplay(lcdHandle,TRUE);
      startButtons();
      return true;
    }else if(command == std::string("OFF"))
    {
      lcdClear(lcdHandle);
      lcdDisplay(lcdHandle,FALSE);
      setBacklightColour(0,0,0);
      stopButtons();
      return true;
    }else if(command == std::string("CURSOR"))
    {
      doCursor(values[2]);
      return true;
    }else if(command == std::string("POSITION"))
    {
      lcdPosition (lcdHandle, toInt(values[2]), toInt(values[3])) ;
      return true;
    }
  }
  return false;

}

void LCDHandler::initAdafruit(const std::string &i2caddress)
{
  mcp23017Setup (AF_BASE, toInt(i2caddress)) ;
  pinMode (AF_RED,   OUTPUT) ;
  pinMode (AF_GREEN, OUTPUT) ;
  pinMode (AF_BLUE,  OUTPUT) ;
 // setBacklightColour (1,1,1) ;

  for (int i = 0 ; i <= 4 ; ++i)
  {
    pinMode (AF_BASE + i, INPUT) ;
    pullUpDnControl (AF_BASE + i, PUD_UP) ;	// Enable pull-ups, switches close to 0v
  }

// Control signals

  pinMode (AF_RW, OUTPUT) ; digitalWrite (AF_RW, LOW) ;	// Not used with wiringPi - always in write mode

// The other control pins are initialised with lcdInit ()

  lcdHandle = lcdInit (2, 16, 4, AF_RS, AF_E, AF_DB4,AF_DB5,AF_DB6,AF_DB7, 0,0,0,0) ;
  if (lcdHandle < 0)
  {
    printf ("lcdInit failed\n") ;
    exit (EXIT_FAILURE) ;
  }

}

void LCDHandler::setBacklightColour (int r, int g, int b)
{
  digitalWrite (AF_RED,   !r) ;
  digitalWrite (AF_GREEN, !g) ;
  digitalWrite (AF_BLUE,  !b) ;
}

void LCDHandler::setText(int x, int y, const std::vector<std::string> &values)
{
  lcdPosition (lcdHandle, x, y) ;
  std::string outputstr = "";
  for(int i = 2; i < values.size(); i++)
  {
    if(i > 2)
       outputstr = outputstr + " ";
    outputstr = outputstr + values[i];
  }

  for(int i =0; i < outputstr.length() - 16 - x; i++)
  {
    outputstr = outputstr + " ";
  }
  lcdPuts     (lcdHandle, outputstr.c_str()) ;

}

void LCDHandler::doCursor(const std::string &state)
{
  if(state == std::string("OFF"))
  {
    lcdCursor (lcdHandle, FALSE) ;
    lcdCursorBlink (lcdHandle, FALSE) ;

  }else if(state == std::string("ON"))
  {
    lcdCursor (lcdHandle, TRUE) ;
    lcdCursorBlink (lcdHandle, FALSE) ;
  }else if(state == std::string("BLINK"))
  {
    lcdCursor (lcdHandle, TRUE) ;
    lcdCursorBlink (lcdHandle, TRUE) ;

  }
}



static void* startButtonHandler(void *ptr)
 {
   LCDHandler *handler = static_cast<LCDHandler*>(ptr);
   handler->runButtons();
 }

void LCDHandler::startButtons()
{
  pthread_create(&ptt,NULL,startButtonHandler,this);
}

void LCDHandler::checkButton(int button)
{
    if (digitalRead (button) == HIGH)	// Wait for push
    {
      delay (1) ;
    }else
    {


      std::stringstream result;
      result << "LCD BUTTON " << buttonNames[button - AF_BASE] << " ON";

      writeString(result.str());

      while (digitalRead (button) == LOW)	// Wait for release
      {
        delay (1) ;
      }
      std::stringstream result2;
      result2 << "LCD BUTTON " << buttonNames[button - AF_BASE] << " OFF";

      writeString(result2.str());
    }
}

void LCDHandler::runButtons(void)
{
 // int pinState = digitalRead(gpioPin);

  while (!stopFlag)
  {
    delay(20);
    checkButton(AF_SELECT);
    checkButton(AF_DOWN);
    checkButton(AF_UP);
    checkButton(AF_LEFT);
    checkButton(AF_RIGHT);
  }

}


void LCDHandler::stopButtons()
{
  stopFlag = true;
}


