#include <pthread.h>
#include "gpiothreadbase.h"

GPIOThreadBase::GPIOThreadBase(): stopFlag(false)
{
  //ctor
}

GPIOThreadBase::~GPIOThreadBase()
{
  stop();
}

static void* startHandler(void *ptr)
{
 GPIOThreadBase *itrpt = static_cast<GPIOThreadBase*>(ptr);
 itrpt->run();
}

void GPIOThreadBase::start()
{

  stopFlag = false;
  pthread_create(&ptt,NULL,startHandler,this);
}

void GPIOThreadBase::stop()
{
  stopFlag = true;
}
