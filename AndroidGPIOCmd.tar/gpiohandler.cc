#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <cstddef>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include <wiringPi.h>

#include "gpiohandler.h"
#include "gpiointerrupt.h"
#include "gpiooutputcycle.h"


#define VERSION "3"




GPIOHandler::GPIOHandler():Handler("GPIO")
{
  interrupt = new GPIOInterrupt(this);
  outputcycle = new GPIOOutputCycle(this);
  i2cLoaded = false;
}

GPIOHandler::~GPIOHandler()
{
  delete interrupt;
  delete outputcycle;
}



static std::string alts [] =
{
  "INPUT", "OUTPUT", "OUTPUT-PWM", "ALT4", "ALT0", "ALT1", "ALT2", "ALT3"
};


void GPIOHandler::writeVersion()
{
  std::stringstream result;
  result << "VERSION " << VERSION << " " << piBoardRev();

  writeString(result.str());
}


void GPIOHandler::getPinState(int pinNumber)
{
  int alt = getAlt(pinNumber);
  std::string altstr = std::string(alts[alt]);
  if(alt == INPUT)
  {
    altstr = altstr + (digitalRead(pinNumber) == HIGH ? "-HIGH" : "-LOW");
  }

  std::stringstream result;
  result << "STATE " << pinNumber << " " << altstr << (digitalRead(pinNumber) == HIGH ? " HIGH" : " LOW");

  writeString(result.str());
}

void GPIOHandler::sendStatus()
{
  for(int i = 1; i <= 26; i++)
  {
    getPinState(i);
  }
}

void GPIOHandler::initAllInterrupts()
{
  removeAllInterrupts();
  for(int i = 1; i <= 26; i++)
  {
    int alt = getAlt(i);
    if(alt == INPUT)
    {
      addInterrupt(i);
    }
  }
}


void GPIOHandler::getPin(int pinNumber)
{
  std::stringstream result;
  result << "PIN " << pinNumber << ((digitalRead(pinNumber) == HIGH) ? " HIGH" : " LOW");

  writeString(result.str());
}

void GPIOHandler::setPin(int pinNumber, const std::string &value1)
{
  digitalWrite(pinNumber,value1 == std::string("HIGH") ? HIGH : LOW);
  getPin(pinNumber);
}

void GPIOHandler::setPWM(int pinNumber, const std::string &value1)
{
  pwmWrite(pinNumber,toInt(value1));
  std::stringstream result;
  result << "PWM " << pinNumber << " " << value1;
  writeString(result.str());
}

void GPIOHandler::setCycle(int pinNumber, const std::string &onoff, const std::string &timeOn, const std::string &timeOff)
{
  if(onoff.compare("ON") == 0)
  {
    setMode(pinNumber,"OUTPUT");
    outputcycle->addPin(pinNumber,toInt(timeOn),toInt(timeOff));
  }else{
    outputcycle->removePin(pinNumber);
  }
}

void GPIOHandler::removeInterrupt(int pinNumber)
{
  interrupt->removePin(pinNumber);
}

void GPIOHandler::addInterrupt(int pinNumber)
{
  if((!w1Loaded) || (w1Loaded && pinNumber != 7) )
  {
    interrupt->addPin(pinNumber,0,0);
  }
}

void GPIOHandler::removeAllInterrupts()
{
  interrupt->removeAllPins();
}

void GPIOHandler::setMode(int pinNumber, const std::string &value1)
{
  if(value1 == std::string("OUTPUT"))
  {
    pinMode(pinNumber,OUTPUT);
    removeInterrupt(pinNumber);
  }
  else if(value1 == std::string("INPUT-HIGH"))
  {
    pinMode(pinNumber,INPUT);
    pullUpDnControl(pinNumber,PUD_UP);
    addInterrupt(pinNumber);
  }
  else if(value1 == std::string("INPUT-LOW"))
  {
    pinMode(pinNumber,INPUT);
    pullUpDnControl(pinNumber,PUD_DOWN);
    addInterrupt(pinNumber);
  }
  else if(value1 == std::string("INPUT-OFF"))
  {
    pinMode(pinNumber,INPUT);
    pullUpDnControl(pinNumber,PUD_OFF);
    addInterrupt(pinNumber);
  }
  else if(value1 == std::string("OUTPUT-PWM"))
  {
    pinMode(pinNumber,PWM_OUTPUT );
    removeInterrupt(pinNumber);
  }

  if(pinNumber <= 26)
  {
    getPinState(pinNumber);
  }else
  {
    std::stringstream result;
    result << "STATE " << pinNumber << " " << value1 << (digitalRead(pinNumber) == HIGH ? " HIGH" : " LOW");

    writeString(result.str());

  }

}

bool GPIOHandler::handler(const std::vector<std::string> &values)
{
  std::string command = values[0];
  std::string value1    = values.size() > 1 ? values[1] : "";
  if(command == std::string("STATUS"))
  {
    sendStatus();
    return true;
  } if(command == std::string("I2C"))
  {
    if(value1 == std::string("LOAD"))
    {
      initI2C();
      return true;
    }else if(value1 == std::string("DETECT"))
    {
      doI2Cdetect();
      return true;
    }

  }
  else
  {
    if(values.size() > 1)
    {
      int pinNumber = toInt(value1);
      std::string value2    = values.size() > 2 ? values[2] : "";
      std::string value3    = values.size() > 3 ? values[3] : "";
      std::string value4    = values.size() > 4 ? values[4] : "";


      if(command == std::string("SET"))
      {
        setPin(pinNumber,value2);
        return true;
      }
      else if(command == std::string("GET"))
      {
        getPin(pinNumber);
        return true;
      }
      else if(command == std::string("MODE"))
      {
        setMode(pinNumber,value2);
        return true;
      }
      else if(command == std::string("PWM"))
      {
        setPWM(pinNumber,value2);
        return true;
      }
      else if(command == std::string("CYCLE"))
      {
        setCycle(pinNumber,value2,value3,value4);
        return true;
      }
    }
  }
  return false;
}


void GPIOHandler::doI2Cdetect ()
{
  writeString("I2CDETECT BEGIN");
  piLock (0);
  if (system ("/usr/local/bin/gpio i2cd") < 0)
    std::cerr << "ERROR Unable to run " << "/usr/local/bin/gpio i2cd" << std::endl;
  piUnlock (0);
  writeString("I2CDETECT END");

}

void GPIOHandler::initI2C()
{
  if(!i2cLoaded)
  {
    piLock (0);
    system ("sudo /sbin/rmmod i2c_dev i2c_bcm2708 > /dev/null 2>&1");
    system ("sudo /sbin/modprobe i2c_bcm2708");
    system ("sudo /sbin/modprobe i2c_dev");
    i2cLoaded = true;
    piUnlock (0);
  }
  writeString("I2C INIT");
}



