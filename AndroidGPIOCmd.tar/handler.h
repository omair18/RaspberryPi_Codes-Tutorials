#ifndef HANDLER_H
#define HANDLER_H

#include <vector>
#include <string>
enum empties_t { empties_ok, no_empties };

std::vector<std::string>& split(
  std::vector<std::string>&result,
  const std::string& s,
  const std::string& delimiters,
  empties_t empties = empties_ok );



class Handler
{
  public:
    Handler(const std::string& identifier);
    virtual ~Handler();

    virtual bool handler(const std::vector<std::string> &values) = 0;
    std::string id();
  protected:
    std::string m_identifier;
    void writeString(const std::string &in);
    int toInt(const std::string &in);
  private:
};

#endif // HANDLER_H
