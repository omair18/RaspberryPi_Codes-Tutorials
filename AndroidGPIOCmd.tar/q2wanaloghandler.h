#ifndef Q2WANALOGHANDLER_H
#define Q2WANALOGHANDLER_H
#include <vector>
#include <string>
#include <map>
#include "handler.h"

class Q2WAnalogHandler: public Handler
{
  public:
    pthread_t ptt;
    Q2WAnalogHandler();
    virtual ~Q2WAnalogHandler();
    virtual bool handler(const std::vector<std::string> &values);
    void run();
  protected:
  private:
    int mSampleTimeMS;
    bool mStop;
    void init(const std::string &i2caddress);

    void start();
    void stop();
};

#endif // Q2WANALOGHANDLER_H
