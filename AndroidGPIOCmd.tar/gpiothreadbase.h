#ifndef GPIOTHREADBASE_H
#define GPIOTHREADBASE_H


class GPIOThreadBase
{
  public:
    GPIOThreadBase();
    virtual ~GPIOThreadBase();

    void stop();
    void start();

    virtual void addPin(int pinNumber, int n1, int n2) = 0;
    virtual void removePin(int pinNumber) = 0;
    virtual void removeAllPins() = 0;

    virtual void run(void) = 0;

  protected:
    pthread_t ptt;

    int sysfd;
    bool stopFlag;
  private:
};

#endif // GPIOTHREADBASE_H
