#ifndef Q2WIOEXPANDERHANDLER_H
#define Q2WIOEXPANDERHANDLER_H
#include <vector>
#include <string>
#include <map>
#include "handler.h"
#include "gpiohandler.h"

class Q2WIOExpanderHandler: public Handler
{
  public:
    Q2WIOExpanderHandler(GPIOHandler *gioHandler);
    virtual ~Q2WIOExpanderHandler();
    virtual bool handler(const std::vector<std::string> &values);
  protected:
  private:
    GPIOHandler *gpioHandler;
    bool initalised;
    void init(const std::string &i2caddress);
    void getPinState(int pinNumber);
    void status();
};

#endif // Q2WANALOGHANDLER_H
