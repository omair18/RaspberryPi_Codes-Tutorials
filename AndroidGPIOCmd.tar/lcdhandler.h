#ifndef LCDHANDLER_H
#define LCDHANDLER_H
#include <vector>
#include <string>
#include <map>
#include "handler.h"

class LCDHandler: public Handler
{
  public:
    LCDHandler();
    virtual ~LCDHandler();
    virtual bool handler(const std::vector<std::string> &values);
    void runButtons();
  protected:
  private:
    pthread_t ptt;
    bool stopFlag;

    //int switchStates[5];

    int lcdHandle;

    void initAdafruit(const std::string &i2caddress);
    void setBacklightColour (int r, int g, int b);
    void setText(int x, int y, const std::vector<std::string> &values);
    void doCursor(const std::string &state);


    void startButtons();
    void stopButtons();

    void checkButton(int button);
};

#endif // LCDHANDLER_H
