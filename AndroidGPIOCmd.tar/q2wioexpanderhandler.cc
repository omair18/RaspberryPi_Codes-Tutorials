#include "q2wioexpanderhandler.h"
#include <wiringPi.h>
#include <mcp23017.h>
#include <stdlib.h>
#include <iostream>
#include <unistd.h>
#include <string>
#include <sstream>

#define Q2W_ABASE 130
#define NUM_IO_PINS 16

Q2WIOExpanderHandler::Q2WIOExpanderHandler(GPIOHandler *gioHandler): Handler("Q2WIO"), gpioHandler(gioHandler)
{
  initalised = false;
}

Q2WIOExpanderHandler::~Q2WIOExpanderHandler()
{
  //dtor
}

/** \brief handle incoming message
 *
 * \param values - string of parameters
 * \return true if handled, false if not
 *
 */
bool Q2WIOExpanderHandler::handler(const std::vector<std::string> &values)
{
  if(values[0] == id())
  {
    std::string command = values[1];
    if(command == std::string("INIT"))
    {
      /**< Q2WIO INIT (I2C Address)[0x21] */
      init(values[2]);
      return true;
    }else if(command == std::string("STATUS"))
    {
      /**< Q2WIO STATUS */
      status();
      return true;
    }
  }
  return false;
}

/** \brief init the mcp23017
 *
 * \param i2caddress
 *
 */
void Q2WIOExpanderHandler::init(const std::string &i2caddress)
{
  if(!initalised)
  {
    mcp23017Setup (Q2W_ABASE,  toInt(i2caddress)) ;
    initalised = true;
  }
}

/** \brief get pin state for the 16 pins.
 *
 */
void Q2WIOExpanderHandler::status()
{
  for(int i = Q2W_ABASE; i <= Q2W_ABASE + NUM_IO_PINS; i++)
  {
    getPinState(i);
  }
}

/** \brief try to determine pin mode
 *
 * \param pinNumber 0-15
 *
 */
void Q2WIOExpanderHandler::getPinState(int pinNumber)
{
  std::string state = "";
  if(digitalRead(pinNumber) == HIGH)
  {
    // consider input
    state = "INPUT-HIGH";
    gpioHandler->setMode(pinNumber,state);
  }else
  {
    gpioHandler->setMode(pinNumber,"OUTPUT");
  }

  std::stringstream result;
  result << "STATE " << pinNumber << " " << state << (digitalRead(pinNumber) == HIGH ? " HIGH" : " LOW");

  writeString(result.str());
}
