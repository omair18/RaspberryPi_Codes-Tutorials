#include <iostream>
#include <wiringPi.h>
#include "gpiohandler.h"
#include "handler.h"
#include "lcdhandler.h"
#include "q2wanaloghandler.h"
#include "q2wioexpanderhandler.h"
#include "ds18b20handler.h"



void run(void)
{
  std::vector<Handler*> handlers = std::vector<Handler*>();
  std::string buffer;

  GPIOHandler *gpiohandler = new GPIOHandler();
  handlers.push_back(gpiohandler);
  handlers.push_back(new LCDHandler());
  handlers.push_back(new Q2WAnalogHandler());
  handlers.push_back(new Q2WIOExpanderHandler(gpiohandler));
  handlers.push_back(new DS18B20Handler(gpiohandler));

  gpiohandler->initAllInterrupts();

  gpiohandler->writeVersion();

  buffer = "";
  std::getline(std::cin,buffer);
  while(!std::cin.eof() && !std::cin.fail() && !std::cin.bad())
  {
    std::vector <std::string> values;

    split(values,buffer," \n\r");

    if(values[0] == "STOP")
    {
      break;
    }

    for(int i = 0; i < handlers.size(); i++)
    {
      if(handlers[i]->handler(values))
      {
        break;
      }
    }

    buffer = "";
    std::getline(std::cin,buffer);
  }
  gpiohandler->removeAllInterrupts();

  for(int i = 0; i < handlers.size(); i++)
  {
    delete handlers[i];
  }
}


int main()
{

  if (wiringPiSetupPhys() == -1)
  {
    return 1 ;
  }

  run();

  return 0;
}
