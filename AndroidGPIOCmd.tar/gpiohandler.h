#ifndef GPIOHANDLER_H
#define GPIOHANDLER_H
#include <string>
#include <vector>
#include <map>
#include "handler.h"
#include "gpiothreadbase.h"


class GPIOHandler: public Handler
{
  public:
    GPIOHandler();
    virtual ~GPIOHandler();
    virtual bool handler(const std::vector<std::string> &values);

    //void getPin(int pinNumber);
//    void run(void) ;
    void set1WLoaded()
    {
      w1Loaded = true;
    }

    void writeVersion();
    void removeAllInterrupts();
    void initAllInterrupts();

    void getPin(int pinNumber);
    void setMode(int pinNumber,  const std::string &value1);
    void setPin(int pinNumber, const std::string &value1);
    void setPWM(int pinNumber, const std::string &value1);
    void setCycle(int pinNumber, const std::string &onoff, const std::string &timeOn, const std::string &timeOff);
  protected:
  private:
    GPIOThreadBase *interrupt;
    GPIOThreadBase *outputcycle;

    bool w1Loaded;
   // int sockfd;
    bool i2cLoaded;

    void getPinState(int pinNumber);
    void sendStatus();



    void removeInterrupt(int gpioPin);
    void addInterrupt(int gpioPin);


    void doI2Cdetect();
    void initI2C();

};

#endif // GPIOHANDLER_H
